package model;

public enum DisplayOrder {
    ASCENDING,
    DESCENDING,
    INORDER,
    POSTORDER,
    PREORDER
}
