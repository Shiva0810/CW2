package helpers;

import java.util.ArrayList;

public class Sorts<E extends Comparable<E>> {
    public void BSort3(ArrayList<E> dataToSort){
       
    }
}

