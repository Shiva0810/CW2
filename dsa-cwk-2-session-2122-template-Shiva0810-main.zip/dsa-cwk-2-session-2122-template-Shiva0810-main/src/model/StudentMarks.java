package model;

public class StudentMarks implements Comparable<StudentMarks>{
    private String StudentMarks;
    private String FirstName;
    private String LastName;
    private int CT1 ;
    private int CT2;
    private int CT3;
    private double ModuleMark;
  
    public StudentMarks(){
        this.StudentMarks = "";
        this.FirstName = "";
        this.LastName = "";
     
    }

    public String getStudentID() {
        return this.StudentMarks;
    }

    public void setStudentID(String studentID) {
        this.StudentMarks = studentID;
    }

    public String getGivenName() {
        return this.FirstName ;
    }

    public void setGivenName(String givenName) {
       this.FirstName = givenName ;
    }

    public String getLastname() {
        return this.LastName ;
    }

    public void setLastname(String lastname) {
        this.LastName = lastname;
    }

    public int getCT1() {
        return this.CT1 ;
    }

    public void setCT1(int CT1) {
        this.CT1 = CT1 ;
    }

    public int getCT2() {
        return this.CT2 ;
    }

    public void setCT2(int CT2) {
        this.CT2 = CT2 ;
    }

    public int getCT3() {
        return this.CT3;
    }

    public void setCT3(int CT3) {
        this.CT3 = CT3;
    }

    public int getModuleMark() {
        return this.ModuleMark;
    }

    public void setModuleMark(int moduleMark) {
        this.ModuleMark = moduleMark ;
    }

    public void calculateModuleMark(){
        this.ModuleMark = (CT1 * 0.3) +(CT2 *0.3) +(CT3 * 0.4);
    }

    public String CSVFormat(){
        String outputStr = this.StudentMarks + "," + this.FirstName + " ," + this.LastName + " ," + this.CT1 + " ," +this.CT2 + " ," + this.CT3 + " ," + this.ModuleMark ;
        return outputStr;
    }

    @Override
    public String toString() {
      return "StudentMarks{" +
                "StudentMarks='" + this.StudentMarks + '\'' +
                ", FirstName='" + this.FirstName + '\'' +
              "LastName='" + this.LastName + '\'' +
              "CT1='" + this.CT1 + '\'' +
              "CT2='" + this.CT2 + '\'' +
              "CT3='" + this.CT3 + '\'' +
              "ModuleMark='" + this.ModuleMark + '\'' +
                '}';
    }

    @Override
    public int compareTo(StudentMarks anEntry) {
        return this.StudentMarks.compareToIgnoreCase(anEntry.getStudentMarks());
    }
}
