package view;

import datastructures.BinarySearchTree;
import datastructures.Node;
import helpers.OutputHelper;
import model.DisplayOrder;
import model.StudentMarks;

public class aView {
    public void displayBSTItemAsc(Node<StudentMarks> root){
         if (root.leftNode != null) {
            displayBSTItemAsc(root.leftNode);
        }
        System.out.format("| %-20s | %-75s |\n", root.getNodeData().getGlossaryEntry(), root.getNodeData().getGlossaryDefinition());
        if (root.rightNode != null) {
            displayBSTItemAsc(root.rightNode);
        }
    }

    public void displayBSTItemDesc(Node<StudentMarks> root){
        if (root.rightNode != null) {
            displayBSTItemDesc(root.rightNode);
        }
        System.out.format("| %-20s | %-75s |\n", root.getNodeData().getGlossaryEntry(), root.getNodeData().getGlossaryDefinition());
        if (root.leftNode != null) {
            displayBSTItemDesc(root.leftNode);
        }
    }

    public void displayBST(BinarySearchTree<StudentMarks> theBST, DisplayOrder order){
         System.out.println(OutputHelper.repeat("-",102));
        System.out.format("| %-20s | %-75s |\n", "Term", "Definition");
        System.out.println(OutputHelper.repeat("-",102));

        switch(order){
            case ASCENDING:
                displayBSTItemAsc(theBST.getRoot());
                break;
            case DESCENDING:
                displayBSTItemDesc(theBST.getRoot());
                break;
                default:
                System.out.println("Oops! Something has went wrong!");
                break;
        }
    }

    public void displayABSTItem(StudentMarks anItem){
         System.out.println(OutputHelper.repeat("-",102));
        System.out.format("| %-20s | %-75s |\n", "Term", "Definition");
        System.out.println(OutputHelper.repeat("-",102));
        System.out.format("| %-20s | %-75s |\n",anItem.getStudentMarks(), anItem.getStudentDefinition());
        System.out.println(OutputHelper.repeat("-",102));
    }

    public void displayStudentScoreInChart(Node<StudentMarks> root){
        // Add your code here
    }

    public void displayAsChart(BinarySearchTree<StudentMarks> theBST){
        // Add your code here
    }
}
