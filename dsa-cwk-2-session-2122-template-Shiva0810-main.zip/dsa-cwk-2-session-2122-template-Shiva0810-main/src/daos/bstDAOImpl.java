package daos;

import app.StudentMarksBST;
import datastructures.BinarySearchTree;
import helpers.Sorts;
import helpers.TextColours;
import model.DisplayOrder;
import model.StudentMarks;
import view.aView;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class bstDAOImpl<E> extends DAO<E>{

    private BinarySearchTree<StudentMarks> theBST;
    private aView theView;
    public static final char DELIMITER = ',';
    public static final char EOLN='\n';
    public static final String QUOTE="\"";
    public static final String USERDIRECTORY = System.getProperty("user.dir");

    private String stripQuotes(String str) {
        return str.substring(1, str.length()-1);
    }

    public bstDAOImpl() {
       this.theBST = new BinarySearchTree<>();
        this.theView = new aView();
    }

    public BinarySearchTree<StudentMarks> getTheBST() {
      return theBST;
    }

    public void setTheBST(BinarySearchTree<StudentMarks> theBST) {
      this.theBST = theBST;
    }

    @Override
    public void loadFromFile(String filename) {
        String transactionFile = USERDIRECTORY +"\\" + filename;
       ArrayList<StudentMarks> dataSet = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(transactionFile))) {
            String theStudentMarks;
            String theStudentDefinition;

            String[] temp;
            String line = br.readLine();
            while(line!=null){
             temp=line.split(Character.toString(DELIMITER));
                theStudentMarks = temp[0];
                theStudentDefinition = temp[1];

                StudentMarks anEntry = new StudentMarks();
                anEntry.setStudentMarks(theStudentMarks);
                anEntry.setStudentDefinition(theStudentDefinition);

                //this.theBST.addNode(anEntry);
                dataSet.add(anEntry);
                line = br.readLine();

            }
            br.close();
        } catch (IOException ex) {
            Logger.getLogger(StudentMarksBST.class.getName()).log(Level.INFO, null, ex);
        }
       this.theBST.createBalancedTree(dataSet,0, dataSet.size() - 1);

    }

    @Override
    public void writeToFile(String filename) {
        
    }

    @Override
    public void add(E theData) {
          this.theBST.addNode((StudentMarks) theData);
    }

    @Override
    public void update(E theData) {

    }

    @Override
    public void findData(int theData) {
       StudentMarks dataToFind = new StudentMarks(theData,"");
        StudentMarks found = theBST.findItem(dataToFind);
        if(found != null){
            this.theView.displayABSTItem(found);
        }
        else{
            System.out.format("The entry %s was %s found!\n", theData, TextColours.TEXT_RED + "not" + TextColours.TEXT_RESET);
        }
    }

    @Override
    public E getData(String theData) {
        return null;
    }

    @Override
    public void removeData(int theData) {
        StudentMarks dataToFind = new StudentMarks(theData,"");
        StudentMarks found = theBST.findItem(dataToFind);
        if(found != null){
            this.theBST.deleteNode(found);
            System.out.format("The entry below has been %s from the tree!\n", TextColours.TEXT_RED + "deleted" + TextColours.TEXT_RESET);
            this.theView.displayABSTItem(found);
        }
        else{
            System.out.format("The entry %s was %s found!\n", theData, TextColours.TEXT_RED + "not" + TextColours.TEXT_RESET);
        }
    }

    public void displayBST(DisplayOrder order){
      this.theView.displayBST(this.theBST, order);
    }

    public void displayBSTChart(){
        // Add your code here
    }

}
